module pid_engine(
	input wire clk, reset, start,
	input wire [15:0] setpoint, 
	input wire [15:0] measurement,
	input wire [15:0] kp,
	input wire [15:0] ki,
	input wire [15:0] kd,
	output wire ready,
	output reg done,
	output wire [15:0] pid_out
);
//Registers for state
reg [1:0] state_reg, state_next;


//Register for PID inputs
reg [15:0] kp_reg, ki_reg, kd_reg;
reg [15:0] setpoint_reg, meas_reg;

//PID variables
reg signed [15:0] error_reg, prev_error_reg, derivative_reg;
reg signed [31:0] integral_reg;
reg signed [31:0] output_reg;
reg [15:0] pid_out_reg;


//FSM states
localparam [1:0] 
			  IDLE 		= 2'b00,
			  COMPUTE 	= 2'b01,
			  DONE 		= 2'b10;

//bdy
//FSMD state transition
always @(posedge clk or posedge reset) begin
	if (reset) begin
		state_reg <= IDLE;
		kp_reg          <= 0;
		ki_reg          <= 0;
		kd_reg          <= 0;
		setpoint_reg    <= 0;
		meas_reg <= 0;
		prev_error_reg  <= 0;
		error_reg       <= 0;
		derivative_reg  <= 0;
		integral_reg    <= 0;
		output_reg		 <= 0;
		pid_out_reg     <= 0;
		done	          <= 0;
	 end else begin
	 state_reg <= state_next;
	case (state_reg)
		IDLE: begin
			done <= 0;
				if (start) begin
					setpoint_reg <= setpoint;
					meas_reg <= measurement;
					kp_reg <= kp;
					ki_reg <= ki;
					kd_reg <= kd;
				end
			end
			COMPUTE: begin
				error_reg <= setpoint_reg - meas_reg;
				integral_reg <= integral_reg + (setpoint_reg - meas_reg);
				derivative_reg <= (setpoint_reg - meas_reg) - prev_error_reg;
				prev_error_reg <= setpoint_reg - meas_reg;
				
				output_reg <= (kp_reg * error_reg) + ((ki_reg * integral_reg)) + (kd_reg * derivative_reg);
				
			end
			DONE: begin
				pid_out_reg <= output_reg[15:0];
				done <= 1;
			end
		endcase
	end
end
	

//FSM next-state logic
always @(*) begin
	case (state_reg)
		IDLE: state_next = start ? COMPUTE : IDLE;
		COMPUTE: state_next = DONE;
		DONE: state_next = IDLE;
		default: state_next = IDLE;
	endcase
end
			
	
//Outputs
assign pid_out = pid_out_reg;
assign ready	= (state_reg == IDLE);

endmodule
	