module avalon_pid 
(
	input wire clk, reset,
	//Avalon-MM slave interface
	input wire [2:0] pid_address,
	input wire pid_write, pid_chipselect,
	input wire [31:0] pid_writedata,
	output wire [31:0] pid_readdata
);


	
//Signals
reg [15:0] setpoint_reg, meas_reg, kp_reg, ki_reg, kd_reg;
wire start;
wire ready, done;
wire [15:0] pid_out;

//PID engine instance
pid_engine core (
	.clk(clk), .reset(reset), .start(start),
	.setpoint(setpoint_reg), .measurement(meas_reg),
	.kp(kp_reg), .ki(ki_reg), .kd(kd_reg),
	.ready(ready), .done(done), .pid_out(pid_out)
);	

//register write decoding
wire wr_en = pid_write & pid_chipselect;
wire wr_kp     = (pid_address == 3'b000) & wr_en;
wire wr_ki     = (pid_address == 3'b001) & wr_en;
wire wr_kd     = (pid_address == 3'b010) & wr_en;
wire wr_set    = (pid_address == 3'b011) & wr_en;
wire wr_meas   = (pid_address == 3'b100) & wr_en;
wire wr_start  = (pid_address == 3'b101) & wr_en;


//Register updates
always @(posedge clk or posedge reset) begin
   if (reset) begin
         kp_reg      <= 0;
         ki_reg      <= 0;
         kd_reg      <= 0;
         setpoint_reg <= 0;
         meas_reg     <= 0;
			//start <= 0;
      end else begin
			//start <=0;	//one-shot pulse
         if (wr_kp)    kp_reg <= pid_writedata[15:0];
         if (wr_ki)    ki_reg <= pid_writedata[15:0];
         if (wr_kd)    kd_reg <= pid_writedata[15:0];
         if (wr_set)   setpoint_reg <= pid_writedata[15:0];
         if (wr_meas)  meas_reg     <= pid_writedata[15:0];
			//if (wr_start) start <= 1;
      end
	end
//Read multiplexer
assign pid_readdata = (pid_address == 3'b110) ? {16'b0, pid_out} :
							 (pid_address == 3'b111) ? {31'b0, done} :
							  32'b0;

endmodule


