// top-level Avalon wrapping circuit
//==================================================================
// R: # reolution bit
// duty signal needs 1 extra bit
//   * e.g., 8- bit resolution need 2^8+1 values (0, 1, 2, ..., 
// DIV: frequency Divider 
//   * tick_freq = pwm_freq * (2^resolution_bit) 
//   * DIV = system_freq / tick_freq 
//   * use 32-bit freq divider
//==================================================================
// register map
// 0x00 for frequency divisor 
// 0x01 for pwm duty cycle
//==================================================================module avalon_pwm 
module pwm_avalon 
	#(
      parameter R = 10  
    )
    (
     input wire clk, reset, 
     // Avalon-MM slave interface
     input wire [1:0] pwm_address,
     input wire pwm_chipselect, pwm_write,
     input wire [31:0] pwm_writedata,
     output wire [31:0] pwm_readdata,
     // to be connected to Avalon conduit interface
     output wire pwm_output
    );
	
	
    // signal declaration 
    reg [R:0]duty_reg;
    reg [31:0]dvsr_reg; 
    wire pwm_out;
    wire wr_en, wr_duty, wr_dvsr;
		  
   // body
   //==================================================================
   // instantiate pwm unit 
   //==================================================================
   pwm_enhanced #(.R(R)) pwm_unit
       (.clk(clk), .reset(reset),  
        .duty(duty_reg), 
	.dvsr(dvsr_reg),  
	.pwm_out(pwm_out));
		  
   //==================================================================
   // registers, decoding, and multiplexing 
   //==================================================================
   // registers
   always @(posedge clk, posedge reset)
   if (reset)
      begin
         duty_reg <= 0;
         dvsr_reg <= 0;
      end   
   else
      begin		
	if (wr_duty)
            duty_reg <= pwm_writedata[R:0];
         if (wr_dvsr)
            dvsr_reg <= pwm_writedata;	
      end 
		
   // write decoding
   assign wr_en = pwm_write & pwm_chipselect;
   assign wr_dvsr = (pwm_address==2'b00) & wr_en;
   assign wr_duty = (pwm_address==2'b01) & wr_en; 
   
   // read data not used 
   assign pwm_readdata = 32'b0;
   
   // conduit signals
   assign pwm_output = pwm_out;  
	
endmodule
