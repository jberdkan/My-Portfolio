module pwm_enhanced
   #(parameter R=10) 
   (
    input clk,
    input reset,
    input [R:0] duty,
    input [31:0] dvsr,
    output pwm_out
   );

   // declaration
   reg [R-1:0] d_reg;
   wire [R-1:0] d_next;
   wire [R:0] d_ext;
	reg [R:0] duty_2d_reg; 
   reg pwm_reg;
   wire pwm_next;
   reg [31:0] q_reg;
   wire [31:0] q_next;
   wire tick;
	
	
	// register file for duty cycles 
   always @(posedge clk)
       duty_2d_reg <= duty;
  
   // body 
   always @(posedge clk or posedge reset)
      if (reset) begin
         d_reg <= 0;
         pwm_reg <= 0;
         q_reg <= 0;
      end 
      else begin
         d_reg <= d_next;
         pwm_reg <= pwm_next;
         q_reg <= q_next;
      end   
   // "prescale" counter
   assign q_next = (q_reg == dvsr) ? 0 : q_reg + 1;
   assign tick = q_reg==0;
   // duty cycle counter
   assign d_next = (tick) ? d_reg + 1 : d_reg;
   assign d_ext = {1'b0, d_reg};
   // comparison circuit 
   //assign pwm_next = d_ext < duty_2d_reg;
   assign pwm_next = (duty_2d_reg == 0) ? 1'b0 : (d_ext < duty_2d_reg);
	assign pwm_out = pwm_reg;
endmodule
