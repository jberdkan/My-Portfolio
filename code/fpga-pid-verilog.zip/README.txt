FPGA PID Temperature Control - Verilog Source
Joyce Berdkan - Liberty University

ghrd_top.v   SoC top level integrating the custom IP
ip/pid/      Custom PID controller IP core (Avalon-MM wrapped)
ip/pwm/      Custom PWM generator IP core (Avalon-MM wrapped)
