RTOS Microcontroller Car - STM32 Source
Joyce Berdkan - ENGC 371, Liberty University

STM32F429 + FreeRTOS. Core/Src and Core/Inc hold the application source;
main.c and freertos.c contain the task logic. FinalV2.ioc is the CubeMX
configuration. Vendor HAL drivers and middleware are omitted.
