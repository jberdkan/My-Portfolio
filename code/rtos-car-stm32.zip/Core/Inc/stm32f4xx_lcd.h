/**
  ******************************************************************************
  * @file    FPU_DEMONSTRATION\Inc\stm32f7xx_julia.h
  * @author  MCD Application Team
  * @version V1.0.0
  * @date    07-September-2016
  * @brief   Mandelbrot-set implementation.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; COPYRIGHT(c) 2016 STMicroelectronics</center></h2>
  *
  * Redistribution and use in source and binary forms, with or without modification,
  * are permitted provided that the following conditions are met:
  *   1. Redistributions of source code must retain the above copyright notice,
  *      this list of conditions and the following disclaimer.
  *   2. Redistributions in binary form must reproduce the above copyright notice,
  *      this list of conditions and the following disclaimer in the documentation
  *      and/or other materials provided with the distribution.
  *   3. Neither the name of STMicroelectronics nor the names of its contributors
  *      may be used to endorse or promote products derived from this software
  *      without specific prior written permission.
  *
  * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
  * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
  * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __STM32F4xx_JULIA_H
#define __STM32F4xx_JULIA_H

#ifdef __cplusplus
 extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx.h"
/* Exported constants --------------------------------------------------------*/
/* Exported types ------------------------------------------------------------*/
#define  ITERATION      	((uint32_t)128)
#define	 REAL_CONSTANT		(0.285f)
#define	 IMG_CONSTANT		(0.01f)
#define  ANIMATION_LENGHT            ((uint32_t)26)
#define XSIZE_PHYS          240
#define YSIZE_PHYS          320

/* define different colors */
#define ILI9341_COLOR_WHITE         0xFFFF
#define ILI9341_COLOR_BLACK         0x0000
#define ILI9341_COLOR_BLUE          0xF800
#define ILI9341_COLOR_GREEN         0x07E0
#define ILI9341_COLOR_GREEN2        0xB723
#define ILI9341_COLOR_RED           0x001F
#define ILI9341_COLOR_BLUE2         0x051D
#define ILI9341_COLOR_YELLOW        0xFFE0
#define ILI9341_COLOR_ORANGE        0xFBE4
#define ILI9341_COLOR_CYAN          0x07FF
#define ILI9341_COLOR_MAGENTA       0xA254
#define ILI9341_COLOR_GRAY          0x7BEF
#define ILI9341_COLOR_BROWN         0xBBCA

//uint16_t Color[ITERATION];/* Color palette */

/* Exported macro ------------------------------------------------------------*/
/* Exported functions ------------------------------------------------------- */
void setbackgroundcolor(uint16_t size_x, uint16_t size_y, uint16_t color, uint16_t * buffer);
void UpdateLCD(uint16_t * image, uint16_t * clut, uint8_t * message);
void InitCLUT(uint16_t*);


#ifdef __cplusplus
}
#endif

#endif /* __STM32F4xx_JULIA_H */

/**
  * @}
  */
/**
  * @}
  */

/************************ (C) COPYRIGHT STMicroelectronics ************************/
