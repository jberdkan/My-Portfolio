/*---------------------------------------------
-- ENGC 361 Lab 3:Desgin Instruction Memory  --
-- Name: Joyce Berdkan & Garrett Good        --
-- The data memory has a single read port.   --

---------------------------------------------*/

module imem(
input wire [31:0] a,
output wire [31:0] rd);

reg [31:0] MEMO[14:0];

initial begin
	//MAIN
   MEMO[0] = 32'hE04F000F; // SUB  R0, R15, R15
   MEMO[1] = 32'hE28010FF; // ADD  R1, R0, #255
   MEMO[2] = 32'hE0812001; // ADD  R2, R1, R1
	MEMO[3] = 32'hE58020C4; // STR  R2, [R0, #196]
   MEMO[4] = 32'hE221304D; // EOR  R3, R1, #77
   MEMO[5] = 32'hE203401F; // AND  R4, R3, #0x1F
	MEMO[6] = 32'hE0835004; // ADD  R5, R3, R4
   MEMO[7] = 32'hE5D56000; // LDRB R6, [R5]
   MEMO[8] = 32'hE5D57001; // LDRB R7, [R5, #1]
	MEMO[9] = 32'hE0560007; // SUBS R0, R6, R7
   MEMO[10] = 32'hBAFFFFF4; // BLT  MAIN
   MEMO[11] = 32'hCA000001; // BGT  HERE
	MEMO[12] = 32'hE584106E; // STR  R1, [R4, #110]
   MEMO[13] = 32'hEAFFFFF1; // B  MAIN
	// HERE
	MEMO[14] = 32'hE584606E; // STR  R6, [R4, #110]
end

assign rd = a[31:2] > 14 ? 0:MEMO[a[31:2]]; // word aligned



endmodule
