/*---------------------------------------------
-- ENGC 361 Lab 3:Desgin Data Memory         --
-- Name: Joyce Berdkan & Garrett Good        --
-- The data memory has a signle read/write   --
-- port.                                     --       

---------------------------------------------*/
module dmem(
				input wire clk, we,
				input wire [31:0] a, wd,
				output reg [31:0] rd);
	reg [31:0] MEMO[255:0]; 
	integer i;
	initial begin
		for (i = 0; i < 256; i = i + 1) begin
			MEMO[i] <= 0;
		end
	end
	
	always @(*) begin
		case(a[1:0])
			//full word access: read the entire 32-bit word from memory at the address indexed by a[31:2]
			2'b00: rd = MEMO[a[31:2]];	
			// Byte access: zero-extend the upper 24 bits and read the most significant byte (bits 31:8) of the word
			2'b01: rd = {(8'b0), MEMO[a[31:2]][31:8]};
			// Halfword access: zero-extend the upper 16 bits and read the most significant 16 bits (bits 31:16) of the word
			2'b10: rd = {(16'b0), MEMO[a[31:2]][31:16]};
			 // Single byte access: zero-extend the upper 24 bits and read only the most significant 8 bits (bit 31) of the word
			2'b11: rd = {(24'b0), MEMO[a[31:2]][31:24]};
			default: rd = MEMO[a[31:2]]; //default case: full word access
		endcase
	end
	
	always @(posedge clk) begin
		if (we) MEMO[a[31:2]] <= wd;
	end
endmodule