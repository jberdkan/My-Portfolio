/*--------------------------------------------------
-- ENGC 361 Lab 5:Control Unit Decoder Design     --
-- Name: Joyce Berdkan & Garrett Good             --
-- With three inputs: Op, Funct, and Rd           --
-- Nine outputs: FlagW, PCS, RegW, MemW, MemtoReg,-- 
--	ALUSrc, ImmSrc, RegSrc, and ALUControl         --

---------------------------------------------*/

module decoder(input [1:0] Op,
					input [5:0] Funct,
					input [3:0] Rd,
					output reg [1:0] FlagW,
					output PCS, 
					output [1:0] RegW, 
					output MemW,
					output MemtoReg, ALUSrc,
					output [1:0] ImmSrc, RegSrc, 
					output reg [2:0] ALUControl);
					
	reg [9:0] controls;
	wire Branch, ALUOp;
	//wire [1:0] BL;
	
	//assign BL = {Funct[2], Funct[0]};
	// Main Decoder
	
	always @(*) begin
		case(Op)
			// Data-processing immediate
			2'b00: if (Funct[5]) controls = 10'b00001010001;
			// Data-processing register
			else controls = 10'b00000010001;
			//LDRB
			2'b01: if (Funct[0] && Funct[2]) controls = 10'b00011111000;
			//LDR
			else if 	 (Funct[0]) controls = 10'b00011110000;
			//STR
			else		 controls = 10'b10011100100;
			// B
			2'b10: controls = 10'b01101000010;
			// Unimplemented
			default: controls = 10'bx;
		endcase
	end
	
	assign {RegSrc, ImmSrc, ALUSrc, MemtoReg,
	RegW, MemW, Branch, ALUOp} = controls;
	
	// ALU Decoder
	always @(*) begin
	if (ALUOp) begin// determine which DP Instruction
		case(Funct[4:1])
			4'b0100: ALUControl = 3'b000; // ADD
			4'b0010: ALUControl = 3'b001; // SUB
			4'b0000: ALUControl = 3'b010; // AND
			4'b1100: ALUControl = 3'b011; // ORR
			4'b0001: ALUControl = 3'b100; // EOR
			default: ALUControl = 3'bx; // unimplemented
		endcase
		
		// update flags if S bit is set (C & V only for arith)
		FlagW[1] = Funct[0];
		FlagW[0] = Funct[0] & (ALUControl == 3'b000 | ALUControl == 3'b001);
		end 
	else begin
		ALUControl = 3'b000; // add for non-DP instructions
		FlagW = 2'b00; // don't update Flags
		end
	end
	
	// PC Logic
	assign PCS = ((Rd == 4'b1111) & RegW[1]) | Branch;
endmodule