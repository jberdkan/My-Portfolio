/*--------------------------------------------------------
-- ENGC 361 Final Project: Single-Cycle Arm Processor   --
-- Name: Joyce Berdkan & Garrett Good                   --
-- ARM module containing the controller and             --
-- datapath                                             --
                      
-- Date:12/04/2024                                      --
---------------------------------------------*/

module arm(input clk, reset,
				output [31:0] PC,
				input [31:0] Instr,
				output MemWrite,
				output [31:0] ALUResult, WriteData,
				input [31:0] ReadData);
				
	wire [3:0] ALUFlags;
	wire [1:0] RegWrite;
	wire ALUSrc, MemtoReg, PCSrc;
	wire [1:0] RegSrc, ImmSrc;
	wire [2:0] ALUControl;
	
	//Instantiate Controller
	controller c(
	.clk(clk), 
	.reset(reset), 
	.Instr(Instr[31:12]), 
	.ALUFlags(ALUFlags),
	.RegSrc(RegSrc), 
	.RegWrite(RegWrite), 
	.ImmSrc(ImmSrc),
	.ALUSrc(ALUSrc), 
	.ALUControl(ALUControl),
	.MemWrite(MemWrite), 
	.MemtoReg(MemtoReg), 
	.PCSrc(PCSrc)
	);
	
	//Instantiate datapath
	datapath dp(
	.clk(clk),
	.reset(reset),
	.RegSrc(RegSrc),
	.RegWrite(RegWrite),
	.ImmSrc(ImmSrc),
	.ALUSrc(ALUSrc),
	.ALUControl(ALUControl), // ADC
	.MemtoReg(MemtoReg),
	.PCSrc(PCSrc),
	.ALUFlags(ALUFlags),
	.PC(PC),
	.Instr(Instr),
	.ALUResult(ALUResult), 
	.WriteData(WriteData),
	.ReadData(ReadData) 
	);
	
endmodule