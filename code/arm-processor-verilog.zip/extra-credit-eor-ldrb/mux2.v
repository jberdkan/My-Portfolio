/*-- ENGC 361 Lab 4: Datapath                             --
-- Name: Joyce Berdkan & Garrett Good                   --
-- Datapath operates on words of data. it contains      --
-- structures such as memories, registers, ALUs, and    --
-- multiplexers.												     --
-- Resettable Flip-Flop                                 --
---------------------------------------------*/

module mux2 #(parameter WIDTH=32)
(input [WIDTH-1:0] d0, d1,
input s,
output [WIDTH-1:0] y);
assign y = s ? d1 : d0;
endmodule