/*--------------------------------------------------------
-- ENGC 361 Lab 4: Datapath                             --
-- Name: Joyce Berdkan & Garrett Good                   --
-- Datapath operates on words of data. it contains      --
-- structures such as memories, registers, ALUs, and    --
-- multiplexers.												     --
-- Extend file                                          --
---------------------------------------------*/

module flopenr #(parameter WIDTH = 8)
					(input clk, reset, en,
					input [WIDTH-1:0] d,
					output reg [WIDTH-1:0] q);
		
	always @(posedge clk, posedge reset)			
		if (reset) q <= 0;
		else if (en) q <= d;
	
endmodule