/*--------------------------------------------- 
-- ENGC 361 Lab 2: ALU    
-- Name: Joyce Berdkan & Garrett Good                          
-- This 32 bit ALU takes inputs a, b, and 
-- ALUControl and outputs a Result and any 
-- ALUFlags. Flags are dertmined by the result
-- and operation being performed.									
															
-- Date: 10/2/2024                           
---------------------------------------------*/

module alu32(
input [31:0] a, b,
input [2:0] ALUControl,
output reg [31:0] Result,
output [3:0] ALUFlags);

wire neg, zero, carryout, overflow;
wire [31:0] condinvb;
wire [32:0] sum;
 
assign condinvb = ALUControl[0] ? ~b : b;
assign sum = a + condinvb + ALUControl[0]; 

always @(*) begin
case(ALUControl[2:0])
 3'b000: Result = sum[31:0]; 	//ADD
 3'b001: Result = sum[31:0];  //SUB
 3'b010: Result = a & b;		//AND
 3'b011: Result = a | b;		//ORR
 3'b100: Result = a ^ b;		//EOR
     endcase
     end

assign neg = Result[31];
assign zero = (Result == 32'b0);
assign carryout = sum[32] & ~ALUControl[1];
assign overflow = (~(ALUControl[0] ^ a[31] ^ b[31]) & (a[31] ^ sum[31]) & ~(ALUControl[1]));
assign ALUFlags = {neg, zero, carryout, overflow};
    endmodule
