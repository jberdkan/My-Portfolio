/*--------------------------------------------------------
-- ENGC 361 Final Project: Single-Cycle Arm Processor   --
-- Name: Joyce Berdkan & Garrett Good                   --
-- Controller stores the current status flags and       --
-- updates them appropriately.                          --
                      
-- Date:12/04/2024                                      --
---------------------------------------------*/
module controller(input clk, reset,
						input [31:12] Instr,
						input [3:0] ALUFlags,
						output [1:0] RegSrc,
						output [1:0] RegWrite,
						output [1:0] ImmSrc,
						output ALUSrc,
						output [2:0] ALUControl,
						output MemWrite, MemtoReg,
						output PCSrc);
						
	wire [1:0] FlagW;
	wire PCS; 
	wire [1:0] RegW; 
	wire MemW;
	
	//Instantiate decoder
	decoder dec(
	.Op(Instr[27:26]), 
	.Funct(Instr[25:20]), 
	.Rd(Instr[15:12]),
	.FlagW(FlagW), 
	.PCS(PCS), 
	.RegW(RegW), 
	.MemW(MemW),
	.MemtoReg(MemtoReg), 
	.ALUSrc(ALUSrc), 
	.ImmSrc(ImmSrc), 
	.RegSrc(RegSrc), 
	.ALUControl(ALUControl)
	);
	
	//Instantiate condlogic
	condlogic cl(
	.clk(clk), 
	.reset(reset), 
	.Cond(Instr[31:28]), 
	.ALUFlags(ALUFlags),
	.FlagW(FlagW), 
	.PCS(PCS), 
	.RegW(RegW), 
	.MemW(MemW),
	.PCSrc(PCSrc), 
	.RegWrite(RegWrite), 
	.MemWrite(MemWrite)
	);
	
endmodule