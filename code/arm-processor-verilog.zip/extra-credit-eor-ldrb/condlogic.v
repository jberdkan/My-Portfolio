/*--------------------------------------------------------
-- ENGC 361 Final Project: Single-Cycle Arm Processor   --
-- Name: Joyce Berdkan & Garrett Good                   --
-- Conditional logic maintains the status flags and     --
-- only enables updates to architectural state when     --
-- the instruction should be conditionally executed.    --
                      
-- Date:12/04/2024                                      --
---------------------------------------------*/

module condlogic(input clk, reset,
						input [3:0] Cond,
						input [3:0] ALUFlags,
						input [1:0] FlagW,
						input PCS, 
						input [1:0] RegW, 
						input MemW,
						output wire PCSrc, 
						output wire [1:0] RegWrite,
						MemWrite);
						
	wire [1:0] FlagWrite;
	wire [3:0] Flags;
	wire CondEx;
// Instantiate two flag registers for stroing ALU flags
	flopenr #(2) flagreg1(	//Negative and zero ALU flags
			.clk(clk), 
			.reset(reset), 
			.en(FlagWrite[1]),
			.d(ALUFlags[3:2]), 
			.q(Flags[3:2])
			);
			
	flopenr #(2) flagreg0(	//Carry and Overflow ALU Flags
			.clk(clk), 
			.reset(reset), 
			.en(FlagWrite[0]),
			.d(ALUFlags[1:0]), 
			.q(Flags[1:0])
			);
			
	condcheck cc(	
			.Cond(Cond), 
			.Flags(Flags), 
			.CondEx(CondEx)
			);
//	Instantiate conditional checker			
	assign FlagWrite = FlagW & {2{CondEx}};
	assign RegWrite = {RegW[1] & CondEx, RegW[0]};
	assign MemWrite = MemW & CondEx;
	assign PCSrc = PCS & CondEx;

endmodule