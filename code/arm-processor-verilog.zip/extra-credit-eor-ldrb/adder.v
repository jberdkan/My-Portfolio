/*---------------------------------------------
-- ENGC 361 Lab 4: Datapath                  --
-- Name: Joyce Berdkan & Garrett Good        --
-- Given by Dr. Wang in to be able to        --
-- complete lab 4                            --
---------------------------------------------*/

module adder #(parameter WIDTH=8)
(input wire [WIDTH-1:0] a, b,
output wire [WIDTH-1:0] y);
assign y = a + b;
endmodule