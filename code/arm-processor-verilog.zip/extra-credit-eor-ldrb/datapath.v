/*--------------------------------------------------------
-- ENGC 361 Lab 4: Datapath                             --
-- Name: Joyce Berdkan & Garrett Good                   --
-- Datapath operates on words of data. it contains      --
-- structures such as memories, registers, ALUs, and    --
-- multiplexers.												     --

---------------------------------------------*/

module datapath(
input clk, reset,
input [1:0] RegSrc,
input [1:0] RegWrite,
input [1:0] ImmSrc,
input ALUSrc,
input [2:0] ALUControl, // ADC
input MemtoReg,
input PCSrc,
output [3:0] ALUFlags,
output [31:0] PC,
input [31:0] Instr,
output [31:0] ALUResult,
output [31:0] WriteData,
input [31:0] ReadData);
// wires
wire [31:0] Result, PCPlus4, PCNext, PCPlus8;
wire [31:0] SrcA, SrcB, ExtImm;
wire [3:0] RA1, RA2;

// next PC logic
// mux for next pc
mux2 #(32) pcmux(
	.d0(PCPlus4), 
	.d1(Result),
	.s(PCSrc),
	.y(PCNext)
);
	 
// pc counter	 
flopr #(32) pcreg(
	.clk(clk),
	.reset(reset),
	.d(PCNext),
	.q(PC)
);

// add 4 to pc
adder #(32) pcadd1(
	.a(PC),
	.b(32'h4),
	.y(PCPlus4)
);

// register file logic
// mux for RA1
mux2 #(32) RA1mux(
	.d0(Instr[19:16]), 
	.d1(4'hF),
	.s(RegSrc[0]),
	.y(RA1)
);

// mux for RA2
mux2 #(32) RA2mux(
	.d0(Instr[3:0]), 
	.d1(Instr[15:12]),
	.s(RegSrc[1]),
	.y(RA2)
);

// register file
regfile rf(
	.clk(clk),
	.reset(reset),
	.we3(RegWrite),
	.ra1(RA1),
	.ra2(RA2),
	.wa3(Instr[15:12]),
	.wd3(Result),
	.r15(PCPlus8),
	.rd1(SrcA),
	.rd2(WriteData)
);

// add 4 to pcplus4
adder #(32) pcadd2(
	.a(PCPlus4),
	.b(32'h4),
	.y(PCPlus8)
);

// extending immediate
extend ext(
	.Instr(Instr[23:0]),
 	.ImmSrc(ImmSrc),
	.ExtImm(ExtImm)
);

// ALU logic
// mux for Source b
mux2 #(32) SrcBmux(
	.d0(WriteData), 
	.d1(ExtImm),
	.s(ALUSrc),
	.y(SrcB)
);

// ALU
alu32 alu(
	.a(SrcA),
	.b(SrcB),
	.ALUControl(ALUControl),
	.Result(ALUResult),
	.ALUFlags(ALUFlags)
);

// mux for result
mux2 #(32) resmux(
	.d0(ALUResult), 
	.d1(ReadData),
	.s(MemtoReg),
	.y(Result)
);
endmodule