`timescale 1ns / 1ps

module top_testbench();
	reg clk;
	reg reset;
	wire [31:0] WriteData, DataAdr;
	wire MemWrite;

	// instantiate device to be tested
	top dut(
	.clk(clk),
	.reset(reset),
	.WriteData(WriteData),
	.DataAdr(DataAdr),
	.MemWrite(MemWrite)
	);
	 

	initial
		begin
		// reset
		reset <= 1; #22; reset <= 0;
		end
	// generate clock to sequence tests
	always
		begin
		//if(~reset) begin
			clk <= 1; 
		
		#5; 
		clk <= 0; 
		#5;
		end
		
	
endmodule