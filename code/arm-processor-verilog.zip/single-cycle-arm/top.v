/*--------------------------------------------------------
-- ENGC 361 Final Project: Single-Cycle Arm Processor   --
-- Name: Joyce Berdkan & Garrett Good                   --
-- Top level module containing the 3 main modules       --
-- which are arm, instrution memory and data memory     --
                      
-- Date:12/04/2024                                      --
---------------------------------------------*/
module top(input clk, reset,
				output [31:0] WriteData, DataAdr,
				output MemWrite);
				
	wire [31:0] PC, Instr, ReadData;
	// instantiate processor and memories
	
	arm arm(
	.clk(clk), 
	.reset(reset), 
	.PC(PC), 
	.Instr(Instr), 
	.MemWrite(MemWrite), 
	.ALUResult(DataAdr),
	.WriteData(WriteData), 
	.ReadData(ReadData)
	);
	
	imem imem(
	.a(PC), 
	.rd(Instr)
	);
	
	dmem dmem(
	.clk(clk), 
	.we(MemWrite), 
	.a(DataAdr), 
	.wd(WriteData), 
	.rd(ReadData)
	);
	
endmodule