/*---------------------------------------------
-- ENGC 361 Lab 3: Register File             --
-- Name: Joyce Berdkan & Garrett Good        --
-- The register file has two read ports and  --                         
-- one write port.                           --

---------------------------------------------*/
module regfile(input clk, reset,
input we3,
input [3:0] ra1, ra2, wa3,
input [31:0] wd3, r15,
output reg [31:0] rd1, rd2);
reg [31:0] rf[14:0];
integer i;
initial begin
for (i = 0; i < 15; i = i + 1) begin
rf[i] <= 0;
end
end
always @(*) begin
rd1 <= (ra1 == 4'b1111) ? r15 : rf[ra1];
rd2 <= (ra2 == 4'b1111) ? r15 : rf[ra2];
end
always @(negedge clk) begin
if (we3) rf[wa3] <= wd3;
end
endmodule