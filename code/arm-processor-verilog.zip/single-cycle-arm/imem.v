/*---------------------------------------------
-- ENGC 361 Lab 3:Desgin Instruction Memory  --
-- Name: Joyce Berdkan & Garrett Good        --
-- The data memory has a single read port.   --

---------------------------------------------*/
module imem(
input wire [31:0] a,
output wire [31:0] rd);


reg [31:0] MEMO[22:0];

// Load instructions
initial begin
	//MAIN
   MEMO[0] = 32'hE04F000F;// Instruction: SUB R0, R15, R15 
   MEMO[1] = 32'hE2802005;// Instruction: ADD R2, R0, #5
   MEMO[2] = 32'hE280300C;// Instruction: ADD R3, R0, #12
	MEMO[3] = 32'hE2437009;// Instruction: SUB R7, R3, #9
	MEMO[4] = 32'hE1874002;// Instruction: ORR R4, R7, R2
   MEMO[5] = 32'hE0035004;// Instruction:	AND R5, R3, R4
   MEMO[6] = 32'hE0855004;// Instruction: ADD R5, R5, R4
   MEMO[7] = 32'hE0558007;// Instruction: SUBS R8, R5, R7
   MEMO[8] = 32'h0A00000C;// Instruction: BEQ END
   MEMO[9] = 32'hE0538004;// Instruction: SUBS R8, R3, R4
   MEMO[10] = 32'hAA000000;// Instruction: BGE AROUND
   MEMO[11] = 32'hE2805000;// Instruction: ADD R5, R0, #0
	//AROUND
   MEMO[12] = 32'hE0578002;// Instruction: SUBS R8, R7, R2
   MEMO[13] = 32'hB2857001;// Instruction: ADDLT R7, R5, #1
   MEMO[14] = 32'hE0477002;// Instruction: SUB R7, R7, R2
   MEMO[15] = 32'hE5837054;// Instruction: STR R7, [R3, #84]
   MEMO[16] = 32'hE5902060;// Instruction: LDR R2, [R0,#96]
   MEMO[17] = 32'hE08FF000;// Instruction: ADD R15, R15, R0
	MEMO[18] = 32'hE280200E;// Instruction: ADD R2, R0, #14
	MEMO[19] = 32'hEA000001;// Instruction: B END
	MEMO[20] = 32'hE280200D;// Instruction: ADD R2, R0, #13
	MEMO[21] = 32'hE280200A;// Instruction: ADD R2, R0, #10
	//END
	MEMO[22] = 32'hE5802064;// Instruction: STR R2, [R0, #100]
end

assign rd = a[31:2] > 22 ? 0:MEMO[a[31:2]]; // word aligned



endmodule
