/*---------------------------------------------
-- ENGC 361 Lab 3:Desgin Data Memory         --
-- Name: Joyce Berdkan & Garrett Good        --
-- The data memory has a signle read/write   --
-- port.                                     --       

---------------------------------------------*/
module dmem(
				input wire clk, we,
				input wire [31:0] a, wd,
				output wire [31:0] rd);

	reg [31:0] MEMO[255:0]; 
	integer i; //as i is less than 256, loop through MEM[i]
	initial begin
		for (i = 0; i < 256; i = i + 1) begin
			MEMO[i] <= 0;
		end
	end 
	
	assign rd = MEMO[a[31:2]]; // word aligned
	
	always @(posedge clk) begin
		if (we) MEMO[a[31:2]] <= wd;
	end
endmodule