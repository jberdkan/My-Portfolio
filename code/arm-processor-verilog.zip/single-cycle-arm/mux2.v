/*---------------------------------------------
-- ENGC 361 Lab 1: Digital Building Blocks   --
-- Name: Joyce Berdkan & Garrett Good        --
-- The two-input multiplexer switches        --
-- one of two digital signals to an output,  --
-- under the select input.                   -- 
-- two-input multiplexer                     --
-- d0 and d1 are the two data inputs         --
-- s is the select input                     --
-- y is the output                           --
                      
---------------------------------------------*/

module mux2 #(parameter WIDTH=32)
(input [WIDTH-1:0] d0, d1,
input s,
output [WIDTH-1:0] y);
assign y = s ? d1 : d0;
endmodule