Single-Cycle ARM Processor — Verilog Source
Joyce Berdkan & Garrett Good — ENGC 361 Computer Architecture, Liberty University

single-cycle-arm/        Base processor: ADD, SUB, AND, ORR, LDR, STR, B
extra-credit-eor-ldrb/   Modified processor adding EOR and LDRB

Target: Intel Quartus Prime / ModelSim. top.v is the FPGA top-level;
top_testbench.v drives simulation. Build artifacts are omitted; they
regenerate on compile.
