`timescale 1ns/1ps
module qam64_modulator_p9_fixed (
    input  wire       rst_n,
    input  wire       SCLK,
    input  wire       MOSI,
    input  wire       CSN,
    output reg        MISO,
    output reg        MISO_enable,
    input  wire       data_clk,
    input  wire       data_in,
    input  wire       dsp_clk,
    output wire signed [11:0] I_out,
    output wire signed [11:0] Q_out
);
    localparam integer NTAPS = 71;

    initial begin
        $display("RUNNING DUT_DROPIN_V5");
    end


    wire rst_n_spi;
    wire rst_n_dsp;
    wire rst_n_data;
    wire rst_spi = ~rst_n_spi;
    wire rst_dsp = ~rst_n_dsp;

    reset_sync_seq3_p9 u_rst_seq (
        .clk_spi    (SCLK),
        .clk_dsp    (dsp_clk),
        .clk_data   (data_clk),
        .rst_n_async(rst_n),
        .rst_n_spi  (rst_n_spi),
        .rst_n_dsp  (rst_n_dsp),
        .rst_n_data (rst_n_data)
    );

    reg map_enable_spi;
    reg [7:0] spi_test_reg;
    reg [3:0] upsample_factor_spi;
    reg signed [7:0] i_coeff_spi [0:NTAPS-1];
    reg signed [7:0] q_coeff_spi [0:NTAPS-1];
    reg signed [11:0] i_store [0:63];
    reg signed [11:0] q_store [0:63];

    integer k;
    integer bi;
    integer rd_bit_idx;

    reg [5:0] spi_bit_count;
    reg       spi_rw;
    reg [9:0] spi_addr_shift;
    reg [9:0] spi_addr_latched;
    reg [7:0] spi_write_shift;
    reg [7:0] spi_read_byte;
    reg       spi_read_active;
    reg       clear_status_after_read;

    wire mapping_active_live;
    reg mapping_active_data;
    wire map_enable_data;
    ff_sync_1bit_p9 u_sync_map_enable (
        .clk   (data_clk),
        .rst_n (rst_n_data),
        .d_async(map_enable_spi),
        .q_sync(map_enable_data)
    );

    wire [7:0] mapper_symbol;
    wire       mapper_new_symbol;
    wire       packet_accepted;

    reg packet_seen_data_tgl;
    reg packet_seen_spi_meta, packet_seen_spi_sync, packet_seen_spi_sync_d;
    reg packet_seen_dsp_meta, packet_seen_dsp_sync, packet_seen_dsp_sync_d;
    reg packet_seen_pending_spi;
    reg mapping_spi_meta, mapping_spi_sync;

    always @(posedge data_clk or negedge rst_n_data) begin
        if (!rst_n_data)
            packet_seen_data_tgl <= 1'b0;
        else if (packet_accepted)
            packet_seen_data_tgl <= ~packet_seen_data_tgl;
    end

    always @(posedge data_clk or negedge rst_n_data) begin
        if (!rst_n_data)
            mapping_active_data <= 1'b0;
        else if (!map_enable_data)
            mapping_active_data <= 1'b0;
        else if (mapping_active_live)
            mapping_active_data <= 1'b1;
    end

    always @(posedge SCLK or negedge rst_n_spi) begin
        if (!rst_n_spi) begin
            packet_seen_spi_meta    <= 1'b0;
            packet_seen_spi_sync    <= 1'b0;
            packet_seen_spi_sync_d  <= 1'b0;
            packet_seen_pending_spi <= 1'b0;
            mapping_spi_meta        <= 1'b0;
            mapping_spi_sync        <= 1'b0;
        end else begin
            packet_seen_spi_meta   <= packet_seen_data_tgl;
            packet_seen_spi_sync   <= packet_seen_spi_meta;
            packet_seen_spi_sync_d <= packet_seen_spi_sync;
            mapping_spi_meta       <= mapping_active_live;
            mapping_spi_sync       <= mapping_spi_meta;
            if (packet_seen_spi_sync ^ packet_seen_spi_sync_d)
                packet_seen_pending_spi <= 1'b1;
            else if (clear_status_after_read && CSN)
                packet_seen_pending_spi <= 1'b0;
        end
    end

    symbol_mapper_64qam_p9_fixed u_mapper (
        .clk            (data_clk),
        .rst_n          (rst_n_data),
        .enable_map     (map_enable_data),
        .data_in        (data_in),
        .symbol_byte    (mapper_symbol),
        .new_symbol     (mapper_new_symbol),
        .mapping_active (mapping_active_live),
        .packet_accepted(packet_accepted)
    );

    wire [7:0] fifo_rd_byte;
    wire fifo_full;
    wire fifo_empty;
    reg  fifo_rd_en;
    reg [1:0] fifo_rd_pending;

    async_fifo_256x8_p9 u_fifo (
        .wr_clk  (data_clk),
        .wr_rst_n(rst_n_data),
        .wr_data (mapper_symbol),
        .wr_en   (mapper_new_symbol),
        .full    (fifo_full),
        .rd_clk  (dsp_clk),
        .rd_rst_n(rst_n_dsp),
        .rd_en   (fifo_rd_en),
        .rd_data (fifo_rd_byte),
        .empty   (fifo_empty)
    );

    reg [3:0] upsample_factor_dsp_m1, upsample_factor_dsp;
    always @(posedge dsp_clk or posedge rst_dsp) begin
        if (rst_dsp) begin
            upsample_factor_dsp_m1 <= 4'd13;
            upsample_factor_dsp    <= 4'd13;
        end else begin
            upsample_factor_dsp_m1 <= upsample_factor_spi;
            upsample_factor_dsp    <= upsample_factor_dsp_m1;
        end
    end

    reg signed [3:0] sym_i;
    reg signed [3:0] sym_q;
    reg              sym_valid;
    reg              sym_prefetch_valid;
    reg [7:0]        sym_prefetch_byte;

    wire signed [3:0] i_up;
    wire signed [3:0] q_up;
    wire i_up_valid;
    wire q_up_valid;
    wire i_in_ready;
    wire q_in_ready;

    always @(posedge dsp_clk or posedge rst_dsp) begin
        if (rst_dsp) begin
            fifo_rd_en         <= 1'b0;
            fifo_rd_pending    <= 2'b00;
            sym_i              <= 4'sd0;
            sym_q              <= 4'sd0;
            sym_valid          <= 1'b0;
            sym_prefetch_valid <= 1'b0;
            sym_prefetch_byte  <= 8'h00;
        end else begin
            fifo_rd_en <= 1'b0;
            sym_valid  <= 1'b0;

            if (fifo_rd_pending[1]) begin
                sym_prefetch_byte  <= fifo_rd_byte;
                sym_prefetch_valid <= 1'b1;
                fifo_rd_pending    <= 2'b00;
            end else if (fifo_rd_pending[0]) begin
                fifo_rd_pending <= 2'b10;
            end

            if (sym_prefetch_valid && i_in_ready && q_in_ready) begin
                sym_i              <= $signed(sym_prefetch_byte[7:4]);
                sym_q              <= $signed(sym_prefetch_byte[3:0]);
                sym_valid          <= 1'b1;
                sym_prefetch_valid <= 1'b0;
            end

            if (!fifo_empty && !sym_prefetch_valid && (fifo_rd_pending == 2'b00)) begin
                fifo_rd_en      <= 1'b1;
                fifo_rd_pending <= 2'b01;
            end
        end
    end

    reg [71*8-1:0] i_coeff_bus;
    reg [71*8-1:0] q_coeff_bus;
    always @(*) begin
        for (bi = 0; bi < NTAPS; bi = bi + 1) begin
            i_coeff_bus[bi*8 +: 8] = i_coeff_spi[bi];
            q_coeff_bus[bi*8 +: 8] = q_coeff_spi[bi];
        end
    end

    upsampler_zero_stuff_p9 u_up_i (
        .clk        (dsp_clk),
        .rst        (rst_dsp),
        .in_sample  (sym_i),
        .in_valid   (sym_valid),
        .interp_rate(upsample_factor_dsp),
        .out_sample (i_up),
        .out_valid  (i_up_valid),
        .in_ready   (i_in_ready)
    );

    upsampler_zero_stuff_p9 u_up_q (
        .clk        (dsp_clk),
        .rst        (rst_dsp),
        .in_sample  (sym_q),
        .in_valid   (sym_valid),
        .interp_rate(upsample_factor_dsp),
        .out_sample (q_up),
        .out_valid  (q_up_valid),
        .in_ready   (q_in_ready)
    );

    wire signed [11:0] I_filt12_out;
    wire signed [11:0] Q_filt12_out;
    wire signed [9:0]  I_filt_out;
    wire signed [9:0]  Q_filt_out;
    wire I_filt_valid;
    wire Q_filt_valid;

    fir71_runtime_cfg_p9 u_fir_i (
        .clk         (dsp_clk),
        .rst         (rst_dsp),
        .in_sample   (i_up),
        .in_valid    (i_up_valid),
        .coeff_bus   (i_coeff_bus),
        .out_sample12(I_filt12_out),
        .out_sample  (I_filt_out),
        .out_valid   (I_filt_valid)
    );

    fir71_runtime_cfg_p9 u_fir_q (
        .clk         (dsp_clk),
        .rst         (rst_dsp),
        .in_sample   (q_up),
        .in_valid    (q_up_valid),
        .coeff_bus   (q_coeff_bus),
        .out_sample12(Q_filt12_out),
        .out_sample  (Q_filt_out),
        .out_valid   (Q_filt_valid)
    );

    assign I_out = I_filt_out;
    assign Q_out = Q_filt_out;

    reg [6:0] store_count;
    reg       store_started;
    always @(posedge dsp_clk or posedge rst_dsp) begin
        if (rst_dsp) begin
            packet_seen_dsp_meta   <= 1'b0;
            packet_seen_dsp_sync   <= 1'b0;
            packet_seen_dsp_sync_d <= 1'b0;
            store_count            <= 7'd0;
            store_started          <= 1'b0;
            for (k = 0; k < 64; k = k + 1) begin
                i_store[k] <= 12'sd0;
                q_store[k] <= 12'sd0;
            end
        end else begin
            packet_seen_dsp_meta   <= packet_seen_data_tgl;
            packet_seen_dsp_sync   <= packet_seen_dsp_meta;
            packet_seen_dsp_sync_d <= packet_seen_dsp_sync;

            if (packet_seen_dsp_sync ^ packet_seen_dsp_sync_d) begin
                store_count   <= 7'd0;
                store_started <= 1'b0;
                for (k = 0; k < 64; k = k + 1) begin
                    i_store[k] <= 12'sd0;
                    q_store[k] <= 12'sd0;
                end
            end else if (I_filt_valid && Q_filt_valid) begin
                if (!store_started) begin
                    if ((I_filt12_out != 12'sd0) || (Q_filt12_out != 12'sd0)) begin
                        store_started <= 1'b1;
                        i_store[0]    <= I_filt12_out;
                        q_store[0]    <= Q_filt12_out;
                        store_count   <= 7'd1;
                    end
                end else if (store_count < 7'd64) begin
		if ((I_filt12_out != 12'sd0) || (Q_filt12_out != 12'sd0)) begin
                    i_store[store_count] <= I_filt12_out;
                    q_store[store_count] <= Q_filt12_out;
                    store_count          <= store_count + 7'd1;
		end
                end
            end
        end
    end

    function [7:0] cfg_read_byte;
        input [9:0] addr;
        reg [6:0] sample_idx;
        begin
            cfg_read_byte = 8'h00;
            if (addr == 10'd0) begin
                cfg_read_byte = {6'b000000, (mapping_spi_sync | packet_seen_pending_spi), map_enable_spi};
    //cfg_read_byte = {6'b000000, mapping_spi_sync, packet_seen_pending_spi};
            end else if (addr == 10'd1) begin
                cfg_read_byte = spi_test_reg;
            end else if (addr == 10'd2) begin
                cfg_read_byte = {4'h0, upsample_factor_spi};
            end else if ((addr >= 10'd128) && (addr <= 10'd198)) begin
                cfg_read_byte = i_coeff_spi[addr - 10'd128];
            end else if ((addr >= 10'd256) && (addr <= 10'd326)) begin
                cfg_read_byte = q_coeff_spi[addr - 10'd256];
            end else if ((addr >= 10'd512) && (addr <= 10'd639)) begin
                sample_idx = (addr - 10'd512) >> 1;
                if (addr[0] == 1'b0)
                    cfg_read_byte = i_store[sample_idx][11:4];
                else
                    cfg_read_byte = {4'b0000, i_store[sample_idx][3:0]};
            end else if ((addr >= 10'd768) && (addr <= 10'd895)) begin
                sample_idx = (addr - 10'd768) >> 1;
                if (addr[0] == 1'b0)
                    cfg_read_byte = q_store[sample_idx][11:4];
                else
                    cfg_read_byte = {4'b0000, q_store[sample_idx][3:0]};
            end
        end
    endfunction

    always @(posedge SCLK or posedge rst_spi) begin
        if (rst_spi) begin
            spi_bit_count           <= 6'd0;
            spi_rw                  <= 1'b0;
            spi_addr_shift          <= 10'd0;
            spi_addr_latched        <= 10'd0;
            spi_write_shift         <= 8'h00;
            spi_read_byte           <= 8'h00;
            spi_read_active         <= 1'b0;
            clear_status_after_read <= 1'b0;
            map_enable_spi          <= 1'b1;
            spi_test_reg            <= 8'h00;
            upsample_factor_spi     <= 4'd13;
            for (k = 0; k < NTAPS; k = k + 1) begin
                i_coeff_spi[k] <= 8'sd0;
                q_coeff_spi[k] <= 8'sd0;
            end
        end else begin
            if (CSN) begin
                spi_bit_count    <= 6'd0;
                spi_addr_shift   <= 10'd0;
                spi_addr_latched <= 10'd0;
                spi_write_shift  <= 8'h00;
                spi_read_active  <= 1'b0;
                if (clear_status_after_read)
                    clear_status_after_read <= 1'b0;
            end else begin
                case (spi_bit_count)
                    6'd0: begin
                        spi_rw         <= MOSI;
                        spi_addr_shift <= 10'd0;
                    end
                    6'd1,6'd2,6'd3,6'd4,6'd5,6'd6,6'd7,6'd8,6'd9,6'd10: begin
                        spi_addr_shift <= {spi_addr_shift[8:0], MOSI};
                        if (spi_bit_count == 6'd10) begin
                            spi_addr_latched <= {spi_addr_shift[8:0], MOSI};
                            if (spi_rw == 1'b0) begin
                                spi_read_byte   <= cfg_read_byte({spi_addr_shift[8:0], MOSI});
                                spi_read_active <= 1'b1;
                                if ({spi_addr_shift[8:0], MOSI} == 10'd0)
                                    clear_status_after_read <= 1'b1;
                            end
                        end
                    end
                    6'd20,6'd21,6'd22,6'd23,6'd24,6'd25,6'd26,6'd27: begin
                        if (spi_rw) begin
                            spi_write_shift <= {spi_write_shift[6:0], MOSI};
                            if (spi_bit_count == 6'd27) begin
                                if (spi_addr_latched == 10'd0) begin
                                    map_enable_spi <= MOSI;
                                end else if (spi_addr_latched == 10'd1) begin
                                    spi_test_reg <= {spi_write_shift[6:0], MOSI};
                                end else if (spi_addr_latched == 10'd2) begin
                                    if (({spi_write_shift[6:0], MOSI} >= 8'h04) && ({spi_write_shift[6:0], MOSI} <= 8'h0D))
                                        upsample_factor_spi <= {spi_write_shift[2:0], MOSI};
                                    else
                                        upsample_factor_spi <= 4'd13;
                                end else if ((spi_addr_latched >= 10'd128) && (spi_addr_latched <= 10'd198)) begin
                                    i_coeff_spi[spi_addr_latched - 10'd128] <= {spi_write_shift[6:0], MOSI};
                                end else if ((spi_addr_latched >= 10'd256) && (spi_addr_latched <= 10'd326)) begin
                                    q_coeff_spi[spi_addr_latched - 10'd256] <= {spi_write_shift[6:0], MOSI};
                                end
                            end
                        end
                    end
                    default: begin end
                endcase

                if (spi_bit_count == 6'd33)
                    spi_bit_count <= 6'd0;
                else
                    spi_bit_count <= spi_bit_count + 6'd1;
            end
        end
    end

    always @(negedge SCLK or posedge rst_spi) begin
        if (rst_spi) begin
            MISO        <= 1'b0;
            MISO_enable <= 1'b0;
        end else if (CSN) begin
            MISO        <= 1'b0;
            MISO_enable <= 1'b0;
        end else begin
            if (spi_read_active && (spi_bit_count >= 6'd20) && (spi_bit_count <= 6'd27)) begin
                rd_bit_idx  = 6'd27 - spi_bit_count;
                MISO        <= spi_read_byte[rd_bit_idx];
                MISO_enable <= 1'b1;
            end else begin
                MISO        <= 1'b0;
                MISO_enable <= 1'b0;
            end
        end
    end
endmodule
