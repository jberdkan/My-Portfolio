`timescale 1ns/1ps
module symbol_mapper_64qam_p9_fixed (
    input  wire       clk,
    input  wire       rst_n,
    input  wire       enable_map,
    input  wire       data_in,
    output reg  [7:0] symbol_byte,
    output reg        new_symbol,
    output reg        mapping_active,
    output reg        packet_accepted
);
    localparam [11:0] HEADER = 12'b101100111000;

    reg [11:0] header_shift;
    reg [5:0]  bit_shift;
    reg [2:0]  bit_count;
    reg [9:0]  payload_bits_left;
    wire [5:0] six_bits;
    assign six_bits = {bit_shift[4:0], data_in};

    function [3:0] map3;
        input [2:0] b;
        begin
            case (b)
                3'b000: map3 = -4'sd7;
                3'b001: map3 = -4'sd5;
                3'b010: map3 = -4'sd3;
                3'b011: map3 = -4'sd1;
                3'b100: map3 =  4'sd1;
                3'b101: map3 =  4'sd3;
                3'b110: map3 =  4'sd5;
                default:map3 =  4'sd7;
            endcase
        end
    endfunction

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            symbol_byte       <= 8'h00;
            new_symbol        <= 1'b0;
            mapping_active    <= 1'b0;
            packet_accepted   <= 1'b0;
            header_shift      <= 12'd0;
            bit_shift         <= 6'd0;
            bit_count         <= 3'd0;
            payload_bits_left <= 10'd0;
        end else begin
            new_symbol      <= 1'b0;
            packet_accepted <= 1'b0;

            if (!enable_map) begin
                symbol_byte       <= 8'h00;
                mapping_active    <= 1'b0;
                header_shift      <= 12'd0;
                bit_shift         <= 6'd0;
                bit_count         <= 3'd0;
                payload_bits_left <= 10'd0;
            end else if (!mapping_active) begin
                header_shift <= {header_shift[10:0], data_in};
                if ({header_shift[10:0], data_in} == HEADER) begin
                    mapping_active    <= 1'b1;
                    packet_accepted   <= 1'b1;
                    payload_bits_left <= 10'd768;
                    bit_shift         <= 6'd0;
                    bit_count         <= 3'd0;
                end
            end else begin
                bit_shift <= six_bits;

                if (bit_count == 3'd5) begin
                    symbol_byte[7:4] <= map3(six_bits[5:3]);
                    symbol_byte[3:0] <= map3(six_bits[2:0]);
                    new_symbol       <= 1'b1;
                    bit_count        <= 3'd0;
                end else begin
                    bit_count <= bit_count + 3'd1;
                end

                if (payload_bits_left == 10'd1) begin
                    mapping_active    <= 1'b0;
                    payload_bits_left <= 10'd0;
                    header_shift      <= 12'd0;
                end else begin
                    payload_bits_left <= payload_bits_left - 10'd1;
                end
            end
        end
    end
endmodule
