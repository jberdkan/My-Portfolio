`timescale 1ns/1ps
module ff_sync_1bit_p9 (
    input  wire clk,
    input  wire rst_n,
    input  wire d_async,
    output reg  q_sync
);
    reg mid;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            mid    <= 1'b0;
            q_sync <= 1'b0;
        end else begin
            mid    <= d_async;
            q_sync <= mid;
        end
    end
endmodule
