`timescale 1ns/1ps
module upsampler_zero_stuff_p9 (
    input  wire              clk,
    input  wire              rst,
    input  wire signed [3:0] in_sample,
    input  wire              in_valid,
    input  wire [3:0]        interp_rate,
    output reg  signed [3:0] out_sample,
    output reg               out_valid,
    output wire              in_ready
);
    reg active;
    reg [3:0] count;
    reg [3:0] rate_hold;
    reg signed [3:0] sample_hold;
    wire [3:0] rate_use;

    assign rate_use = (interp_rate < 4)  ? 4'd4  :
                      (interp_rate > 13) ? 4'd13 : interp_rate;
    assign in_ready = ~active || (active && (count == rate_hold - 4'd1));

    always @(posedge clk) begin
        if (rst) begin
            active      <= 1'b0;
            count       <= 4'd0;
            rate_hold   <= 4'd4;
            sample_hold <= 4'sd0;
            out_sample  <= 4'sd0;
            out_valid   <= 1'b0;
        end else begin
            out_sample <= 4'sd0;
            out_valid  <= 1'b0;
          if (active) begin
    out_valid  <= 1'b1;
    out_sample <= (count == 4'd0) ? sample_hold : 4'sd0;
    if (count == rate_hold - 4'd1) begin
        if (in_valid) begin
            // back-to-back: accept next symbol with no gap
            sample_hold <= in_sample;
            rate_hold   <= rate_use;
            out_sample  <= in_sample;
            active      <= 1'b1;
            count       <= 4'd1;
        end else begin
            active <= 1'b0;
            count  <= 4'd0;
        end
    end else begin
        count <= count + 4'd1;
    end
end else if (in_valid) begin
    sample_hold <= in_sample;
    rate_hold   <= rate_use;
    out_valid   <= 1'b1;
    out_sample  <= in_sample;
    if (rate_use == 4'd1) begin
        active <= 1'b0;
        count  <= 4'd0;
    end else begin
        active <= 1'b1;
        count  <= 4'd1;
    end
end
        end
    end
endmodule
