`timescale 1ns/1ps
module fir71_runtime_cfg_p9 (
    input  wire               clk,
    input  wire               rst,
    input  wire signed [3:0]  in_sample,
    input  wire               in_valid,
    input  wire [71*8-1:0]    coeff_bus,
    output reg  signed [11:0] out_sample12,
    output reg  signed [9:0]  out_sample,
    output reg                out_valid
);
    localparam integer NTAPS = 71;

    reg signed [3:0] x_hist [0:NTAPS-1];
    reg [6:0] flush_count;
    integer i;
    reg signed [3:0] sample_use;
    reg process_en;
    reg signed [18:0] acc_calc;
    reg signed [11:0] out12_calc;

    function signed [7:0] coeff_at;
        input integer idx;
        begin
            coeff_at = $signed(coeff_bus[idx*8 +: 8]);
        end
    endfunction

    function signed [11:0] sat12;
        input signed [18:0] x;
        begin
            if (x > 19'sd2047)
                sat12 = 12'sd2047;
            else if (x < -19'sd2048)
                sat12 = -12'sd2048;
            else
                sat12 = x[11:0];
        end
    endfunction

    function signed [9:0] round_to_zero_12_to_10;
        input signed [11:0] x;
        reg signed [11:0] mag12;
        reg signed [9:0]  mag10;
        begin
            if (x >= 12'sd0)
                round_to_zero_12_to_10 = x[11:2];
            else begin
                mag12 = -x;
                mag10 = mag12[11:2];
                round_to_zero_12_to_10 = -mag10;
            end
        end
    endfunction

    always @(*) begin
        process_en = in_valid || (flush_count != 7'd0);
        sample_use = in_valid ? in_sample : 4'sd0;

        acc_calc = 19'sd0;
        if (process_en) begin
            acc_calc = acc_calc + $signed(sample_use) * $signed(coeff_at(0));
            for (i = 1; i < NTAPS; i = i + 1)
                acc_calc = acc_calc + $signed(x_hist[i-1]) * $signed(coeff_at(i));
        end
        out12_calc = sat12(acc_calc);
    end

    always @(posedge clk or posedge rst) begin
        if (rst) begin
            for (i = 0; i < NTAPS; i = i + 1)
                x_hist[i] <= 4'sd0;
            flush_count <= 7'd0;
            out_sample12 <= 12'sd0;
            out_sample   <= 10'sd0;
            out_valid    <= 1'b0;
        end else begin
            if (process_en) begin
                x_hist[0] <= sample_use;
                for (i = 1; i < NTAPS; i = i + 1)
                    x_hist[i] <= x_hist[i-1];

                out_sample12 <= out12_calc;
                out_sample   <= round_to_zero_12_to_10(out12_calc);
                out_valid    <= 1'b1;
            end else begin
                out_sample12 <= 12'sd0;
                out_sample   <= 10'sd0;
                out_valid    <= 1'b0;
            end

            if (in_valid)
                flush_count <= NTAPS - 1;
            else if (flush_count != 7'd0)
                flush_count <= flush_count - 7'd1;
            else
                flush_count <= 7'd0;
        end
    end
endmodule
