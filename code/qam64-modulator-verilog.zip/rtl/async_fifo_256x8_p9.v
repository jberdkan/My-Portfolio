`timescale 1ns/1ps
module async_fifo_256x8_p9 (
    input  wire       wr_clk,
    input  wire       wr_rst_n,
    input  wire [7:0] wr_data,
    input  wire       wr_en,
    output wire       full,
    input  wire       rd_clk,
    input  wire       rd_rst_n,
    input  wire       rd_en,
    output reg  [7:0] rd_data,
    output wire       empty
);
    localparam AW = 8;
    localparam PW = AW + 1;

    reg [7:0] mem [0:(1<<AW)-1];

    reg [PW-1:0] wr_ptr_bin, wr_ptr_bin_next;
    reg [PW-1:0] wr_ptr_gray, wr_ptr_gray_next;
    reg [PW-1:0] rd_ptr_bin, rd_ptr_bin_next;
    reg [PW-1:0] rd_ptr_gray, rd_ptr_gray_next;

    reg [PW-1:0] rd_ptr_gray_wr1, rd_ptr_gray_wr2;
    reg [PW-1:0] wr_ptr_gray_rd1, wr_ptr_gray_rd2;

    wire wr_fire = wr_en & ~full;
    wire rd_fire = rd_en & ~empty;

    function [PW-1:0] bin2gray;
        input [PW-1:0] b;
        begin
            bin2gray = (b >> 1) ^ b;
        end
    endfunction

    assign full  = (wr_ptr_gray_next == {~rd_ptr_gray_wr2[PW-1:PW-2], rd_ptr_gray_wr2[PW-3:0]});
    assign empty = (rd_ptr_gray == wr_ptr_gray_rd2);

    always @(*) begin
        wr_ptr_bin_next  = wr_ptr_bin + wr_fire;
        wr_ptr_gray_next = bin2gray(wr_ptr_bin_next);
        rd_ptr_bin_next  = rd_ptr_bin + rd_fire;
        rd_ptr_gray_next = bin2gray(rd_ptr_bin_next);
    end

    always @(posedge wr_clk or negedge wr_rst_n) begin
        if (!wr_rst_n) begin
            wr_ptr_bin  <= {PW{1'b0}};
            wr_ptr_gray <= {PW{1'b0}};
            rd_ptr_gray_wr1 <= {PW{1'b0}};
            rd_ptr_gray_wr2 <= {PW{1'b0}};
        end else begin
            rd_ptr_gray_wr1 <= rd_ptr_gray;
            rd_ptr_gray_wr2 <= rd_ptr_gray_wr1;
            if (wr_fire)
                mem[wr_ptr_bin[AW-1:0]] <= wr_data;
            wr_ptr_bin  <= wr_ptr_bin_next;
            wr_ptr_gray <= wr_ptr_gray_next;
        end
    end

    always @(posedge rd_clk or negedge rd_rst_n) begin
        if (!rd_rst_n) begin
            rd_ptr_bin  <= {PW{1'b0}};
            rd_ptr_gray <= {PW{1'b0}};
            wr_ptr_gray_rd1 <= {PW{1'b0}};
            wr_ptr_gray_rd2 <= {PW{1'b0}};
            rd_data <= 8'h00;
        end else begin
            wr_ptr_gray_rd1 <= wr_ptr_gray;
            wr_ptr_gray_rd2 <= wr_ptr_gray_rd1;
            if (rd_fire)
                rd_data <= mem[rd_ptr_bin[AW-1:0]];
            else
                rd_data <= 8'h00;
            rd_ptr_bin  <= rd_ptr_bin_next;
            rd_ptr_gray <= rd_ptr_gray_next;
        end
    end
endmodule
