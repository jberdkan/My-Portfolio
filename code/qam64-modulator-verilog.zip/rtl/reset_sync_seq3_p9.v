`timescale 1ns/1ps
module reset_sync_seq3_p9 (
    input  wire clk_spi,
    input  wire clk_dsp,
    input  wire clk_data,
    input  wire rst_n_async,
    output wire rst_n_spi,
    output wire rst_n_dsp,
    output wire rst_n_data
);
    reg [2:0] spi_ff;
    reg [2:0] dsp_ff;
    reg [2:0] data_ff;

    always @(posedge clk_spi or negedge rst_n_async) begin
        if (!rst_n_async)
            spi_ff <= 3'b00;
        else
            spi_ff <= {spi_ff[1:0], 1'b1};
    end

    always @(posedge clk_dsp or negedge rst_n_spi) begin
        if (!rst_n_spi)
            dsp_ff <= 3'b000;
        else
            dsp_ff <= {dsp_ff[1:0], 1'b1};
    end

    always @(posedge clk_data or negedge rst_n_dsp) begin
        if (!rst_n_dsp)
            data_ff <= 3'b00;
        else
            data_ff <= {data_ff[1:0], 1'b1};
    end

    assign rst_n_spi  = spi_ff[2];
    assign rst_n_dsp  = dsp_ff[2];
    assign rst_n_data = data_ff[2];
endmodule
