64-QAM Digital Modulator - Verilog Source
Joyce Berdkan & Syed Hasan - ECE 6214, George Washington University

rtl/   Modulator RTL: symbol mapper, FIR, upsampler, async FIFO (CDC), reset sync
       qam64_modulator_p9_fixed.v is the top module
sim/   Self-checking testbench
