`timescale 1ns/10ps
module alucontrol( aluop, funct, alucont );

    input [1:0] aluop;
    input [5:0] funct;
    output [2:0] alucont;

    reg [2:0] alucont;

    always @(*)
        case (aluop)
            2'b00: alucont = 3'b010;  // add  (lw/sw/lb/sb address)
            2'b01: alucont = 3'b110;  // sub  (beq)
            2'b10: case (funct)
                6'b100000: alucont = 3'b010; // add
                6'b100010: alucont = 3'b110; // sub
                6'b100100: alucont = 3'b000; // and
                6'b100101: alucont = 3'b001; // or
                6'b101010: alucont = 3'b111; // slt
                default:   alucont = 3'b010;
            endcase
            default: alucont = 3'b010;
        endcase

endmodule
