`timescale 1ns/10ps
module alu (a, b, alucont, result) ;

    input [7:0] a, b;
    input [2:0] alucont;
    output [7:0] result;

    reg [7:0] result;
    wire [7:0] b2, sum, slt;

    assign b2  = alucont[2] ? ~b : b;
    assign sum = a + b2 + {7'b0, alucont[2]};
    assign slt = {7'b0, sum[7]};

    always @(*)
        case (alucont[1:0])
            2'b00: result = a & b2;
            2'b01: result = a | b2;
            2'b10: result = sum;
            2'b11: result = slt;
        endcase

endmodule

