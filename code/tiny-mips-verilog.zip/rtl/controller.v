`timescale 1ns/10ps
module controller(clk, reset, op, zero, memread, memwrite, alusrca, memtoreg, iord, pcen, regwrite, regdst,
pcsource, alusrcb, aluop, irwrite) ;

    input [5:0] op;
    input clk, reset;
    input zero;

    output alusrca;
    output [1:0] alusrcb;
    output [1:0] aluop;
//  output branch;
    output iord;
    output memread;
    output memwrite;
    output memtoreg;
//  output pcwrite;
    output [1:0] pcsource;
    output regwrite;
    output regdst;
    output pcen;
    output [3:0] irwrite;

    reg alusrca;
    reg [1:0] alusrcb;
    reg [1:0] aluop;
    reg branch;
    reg iord;
    reg [3:0] irwrite;
    reg memread;
    reg memwrite;
    reg memtoreg;
    reg [1:0] pcsource;
    reg regwrite;
    reg regdst;

    reg [3:0] state, nextstate;
    reg pcwrite, pcwritecond;

    // pcen: advance PC when pcwrite set, or branch taken
    assign pcen = pcwrite | (pcwritecond & zero);

    // State register
    always @(posedge clk or posedge reset)
        if (reset) state <= 4'd0;
        else       state <= nextstate;

    // Next-state logic
    always @(*) begin
        case (state)
            4'd0:  nextstate = 4'd1;   // fetch byte 0
            4'd1:  nextstate = 4'd2;   // fetch byte 1
            4'd2:  nextstate = 4'd3;   // fetch byte 2
            4'd3:  nextstate = 4'd4;   // fetch byte 3 / decode
            4'd4:  begin               // decode / dispatch
                case (op)
                    6'b100000: nextstate = 4'd5;  // lb  -> mem addr
                    6'b101000: nextstate = 4'd5;  // sb  -> mem addr
                    6'b000000: nextstate = 4'd9;  // R-type execute
                    6'b001000: nextstate = 4'd9;  // addi execute
                    6'b000100: nextstate = 4'd11; // beq
                    6'b000010: nextstate = 4'd12; // j
                    default:   nextstate = 4'd0;
                endcase
            end
            4'd5:  begin               // memory address calc
                if (op == 6'b100000) nextstate = 4'd6;  // lb -> mem read
                else                  nextstate = 4'd8;  // sb -> mem write
            end
            4'd6:  nextstate = 4'd7;   // mem read -> writeback
            4'd7:  nextstate = 4'd0;   // lb writeback -> fetch
            4'd8:  nextstate = 4'd0;   // sb mem write -> fetch
            4'd9:  nextstate = 4'd10;  // execute -> writeback (R-type and addi)
            4'd10: nextstate = 4'd0;   // reg writeback -> fetch
            4'd11: nextstate = 4'd0;   // beq -> fetch
            4'd12: nextstate = 4'd0;   // j   -> fetch
            default: nextstate = 4'd0;
        endcase
    end

    // Output logic (registered outputs set combinatorially, latched by state reg)
    always @(*) begin
        // defaults
        alusrca     = 0;
        alusrcb     = 2'b01;  // +1 (PC increment default)
        aluop       = 2'b00;
        branch      = 0;
        iord        = 0;
        irwrite     = 4'b0000;
        memread     = 0;
        memwrite    = 0;
        memtoreg    = 0;
        pcwrite     = 0;
        pcwritecond = 0;
        pcsource    = 2'b00;
        regwrite    = 0;
        regdst      = 0;

        case (state)
            4'd0: begin  // fetch byte 0 → mem[PC] goes to instr[31:24]
                memread  = 1;
                irwrite  = 4'b1000;
                alusrcb  = 2'b01;
                pcwrite  = 1;
                pcsource = 2'b00;
            end
            4'd1: begin  // fetch byte 1 → mem[PC+1] goes to instr[23:16]
                memread  = 1;
                irwrite  = 4'b0100;
                alusrcb  = 2'b01;
                pcwrite  = 1;
                pcsource = 2'b00;
            end
            4'd2: begin  // fetch byte 2 → mem[PC+2] goes to instr[15:8]
                memread  = 1;
                irwrite  = 4'b0010;
                alusrcb  = 2'b01;
                pcwrite  = 1;
                pcsource = 2'b00;
            end
            4'd3: begin  // fetch byte 3 → mem[PC+3] goes to instr[7:0]
                memread  = 1;
                irwrite  = 4'b0001;
                alusrcb  = 2'b01;
                pcwrite  = 1;
                pcsource = 2'b00;
            end
            4'd4: begin  // decode: compute branch target (PC already past instr)
                alusrca  = 0;
                alusrcb  = 2'b11;  // constx4
                aluop    = 2'b00;
            end
            4'd5: begin  // memory address calculation (lb/sb)
                alusrca  = 1;
                alusrcb  = 2'b10;  // sign-ext imm
                aluop    = 2'b00;
            end
            4'd6: begin  // lb mem read
                memread  = 1;
                iord     = 1;
            end
            4'd7: begin  // lb writeback
                regwrite = 1;
                regdst   = 0;
                memtoreg = 1;
            end
            4'd8: begin  // sb mem write
                memwrite = 1;
                iord     = 1;
            end
            4'd9: begin  // ALU execute (R-type or addi)
                alusrca  = 1;
                aluop    = 2'b10;
                alusrcb  = (op == 6'b001000) ? 2'b10 : 2'b00; // imm for addi, rd2 for R-type
            end
            4'd10: begin  // register writeback (R-type: rd; addi: rt)
                regwrite = 1;
                regdst   = (op == 6'b000000) ? 1'b1 : 1'b0;
                memtoreg = 0;
            end
            4'd11: begin  // beq
                alusrca     = 1;
                alusrcb     = 2'b00;
                aluop       = 2'b01;
                pcwritecond = 1;
                pcsource    = 2'b01;  // aluout (branch target computed in state 4)
            end
            4'd12: begin  // j
                pcwrite  = 1;
                pcsource = 2'b10;  // constx4 (jump target)
            end
        endcase
    end

endmodule
