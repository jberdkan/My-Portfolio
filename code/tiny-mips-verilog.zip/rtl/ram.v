`timescale 1ns/10ps
module ram (memdata, memwrite, adr, writedata, clk);

    output [7:0] memdata;
    input memwrite;
    input [7:0] adr;
    input [7:0] writedata;
    input clk;

    reg [7:0] memdata;
    reg [7:0] mips_ram [0:255];

    integer i, k;

    initial begin
        for (i=0; i<256; i=i+1)
            mips_ram[i]=8'b0;
        $display("RAM: Memory initialized to 0");

        //loads contents of memory from a file called: ram.dat
        $readmemb("../ram.dat", mips_ram);
        $display("RAM: External Memory File: ram.dat laoded into RAM.");
        //
        // displays. contents of memory after file loads
        //
        $display("RAM: Contents of Mem after reading data file:");
        for (k=0; k<256; k=k+1)
            $display("%d:%b",k,mips_ram[k]);
    end 

    //the behavioral descirption of the RAM - note clocked behavior
    always @(negedge clk) begin 
        if (memwrite) begin 
            mips_ram[adr] = writedata;
            $writememb("ram.after.dat", mips_ram);
        end
        memdata <= mips_ram[adr];
    end
endmodule
