Tiny MIPS CPU - Verilog Source
Joyce Berdkan & Syed Hasan - ECE 6214, George Washington University

rtl/   Multi-cycle Tiny MIPS RTL (mips.v is the top module)
sim/   Self-checking testbench and ram.dat program image
