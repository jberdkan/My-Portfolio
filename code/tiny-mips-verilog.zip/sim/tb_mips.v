`timescale 1ns/10ps
// ============================================================
// Self-checking testbench for Tiny MIPS CPU
// Covers: lb, sb, add, sub, and, or, slt, addi, beq, j
//
// TEST GROUP 1 loads its program via ram.dat (using $readmemb
// inside ram.v) – following the Lab 3 memory-loading pattern.
// TEST GROUP 2 manually writes instructions for extended tests.
//
// Instruction byte order (big-endian, MSB at lowest address):
//   mem[PC+0] = instr[31:24]   (contains opcode)
//   mem[PC+1] = instr[23:16]
//   mem[PC+2] = instr[15:8]
//   mem[PC+3] = instr[7:0]
//
// Register map (3-bit index):
//   $s0=000  $s1=001  $s2=010  $s3=011
//   $s4=100  $s5=101  $s6=110  $s7=111
//   $zero is hardwired 0 (address 0)
//
// Field positions inside the 32-bit instruction word:
//   op    [31:26]
//   rs    [23:21]   (3-bit, tiny MIPS)
//   rt    [18:16]   (3-bit)
//   rd    [13:11]   (3-bit, R-type destination)
//   imm   [7:0]     (I-type / J-type)
//   funct [5:0]     (R-type)
// ============================================================

// -------------------------------------------------------
// Parameter / macro definitions  (Lab 3 item #1/#2)
// -------------------------------------------------------
`define DELAY       5       // inter-stimulus delay (ns)
`define CLK_HALF    10      // half clock period  (ns) → 20 ns total
`define FINISH_TIME 500000  // watchdog timeout   (ns)

module tb_mips;

    // -----------------------------------------------------------
    // Parameters (Lab 3 item #1)
    // -----------------------------------------------------------
    parameter finishtime   = `FINISH_TIME;
    parameter reset_cycles = 3;

    // -----------------------------------------------------------
    // DUT signals
    // -----------------------------------------------------------
    reg        clk, reset;
    wire       memread, memwrite;
    wire [7:0] adr, writedata, memdata;

    // -----------------------------------------------------------
    // Instantiate CPU  (named-port style – Lab 3 item #7)
    // -----------------------------------------------------------
    mips cpu (
        .clk      (clk),
        .reset    (reset),
        .memdata  (memdata),
        .memread  (memread),
        .memwrite (memwrite),
        .adr      (adr),
        .writedata(writedata)
    );

    // -----------------------------------------------------------
    // Instantiate RAM  (named-port style – Lab 3 item #7)
    //
    // ram.v zeros its array then calls:
    //   $readmemb("ram.dat", mips_ram)
    // so at time-0 the RAM already contains the program from
    // ram.dat – exactly the Lab 3 "Using Memory in a Testbench"
    // pattern.  Test Group 1 simply resets the CPU and runs.
    // -----------------------------------------------------------
    ram memory (
        .memdata  (memdata),
        .memwrite (memwrite),
        .adr      (adr),
        .writedata(writedata),
        .clk      (clk)
    );

    // -----------------------------------------------------------
    // Clock generation  (Lab 3 item #3 timescale already set)
    // -----------------------------------------------------------
    initial clk = 0;
    always  #`CLK_HALF clk = ~clk;

    // -----------------------------------------------------------
    // Cycle counter
    // -----------------------------------------------------------
    integer cycle;
    initial cycle = 0;
    always @(posedge clk) cycle = cycle + 1;

    // -----------------------------------------------------------
    // Waveform dump  (Lab 3 item #10 debug output)
    // -----------------------------------------------------------
    initial begin
        $dumpfile("tb_mips.vcd");
        $dumpvars(0, tb_mips);
    end

    // -----------------------------------------------------------
    // Error counter + self-check helper  (Lab 3 item #10)
    // -----------------------------------------------------------
    integer errors;

    task check_mem;
        input [7:0] addr;
        input [7:0] expected;
        input [8*12:1] label;
        begin
            if (memory.mips_ram[addr] === expected)
                $display("  PASS  %-12s  mem[%0d] = %0d (0x%02h)",
                         label, addr, expected, expected);
            else begin
                $display("  FAIL  %-12s  mem[%0d] = %0d (0x%02h), expected %0d (0x%02h)",
                         label, addr,
                         memory.mips_ram[addr], memory.mips_ram[addr],
                         expected, expected);
                errors = errors + 1;
            end
        end
    endtask

    // -----------------------------------------------------------
    // Utility: clear all 256 RAM bytes to 0  (used by Group 2)
    // -----------------------------------------------------------
    integer _i;
    task clear_ram;
        begin
            for (_i = 0; _i < 256; _i = _i + 1)
                memory.mips_ram[_i] = 8'h00;
        end
    endtask

    // -----------------------------------------------------------
    // Utility: apply reset for reset_cycles then release
    // -----------------------------------------------------------
    task do_reset;
        begin
            reset = 1;
            repeat(reset_cycles) @(posedge clk); #1;
            reset = 0;
        end
    endtask

    // ===========================================================
    // MAIN STIMULUS  (Lab 3 item #8 – separate initial blocks
    //                 for init, stimulus, and waveform capture)
    // ===========================================================

    // --- Initial conditions block  (Lab 3 item #8) ---
    initial begin
        errors = 0;
        reset  = 1;
        clk    = 0;
        $display("----------------------------------------------------");
        $display(" Tiny MIPS Testbench – Lab 3 structured style");
        $display("----------------------------------------------------");
        $monitor("TIME=%0t  adr=%0d  memwrite=%b  writedata=%0d",
                 $time, adr, memwrite, writedata);
    end

    // --- Test stimulus block  (Lab 3 item #9) ---
    initial begin
        // Give the initial block above a head-start
        #1;

        // =======================================================
        // TEST GROUP 1 – PROGRAM LOADED FROM ram.dat
        //
        // ram.v already called $readmemb("ram.dat", mips_ram) at
        // time 0.  The program in ram.dat is:
        //
        //   addr  0-3 : lb $s2, 20($0)   -> $s2 = mem[20] = 1
        //   addr  4-7 : lb $s3, 21($0)   -> $s3 = mem[21] = 2
        //   addr  8-11: add $s1,$s2,$s3  -> $s1 = 3
        //   addr 12-15: sb $s1, 255($0)  -> mem[255] = 3
        //   addr 16-19: j 0              -> loop
        //   addr 20   : 0x01  (data for $s2)
        //   addr 21   : 0x02  (data for $s3)
        //
        // We simply reset and run – no manual RAM writes needed.
        // =======================================================
        $display("\n====================================================");
        $display(" TEST GROUP 1: ram.dat program  (lb/add/sb/j)");
        $display("====================================================");
        $display(" RAM loaded from ram.dat by $readmemb in ram.v");

        do_reset;
        $display("Reset released at cycle %0d. Running...", cycle);

        // lb×2 + add + sb + j → allow a generous number of cycles
        repeat(60) @(posedge clk);

        $display("Checking after %0d cycles:", cycle);
        check_mem(8'd255, 8'd3, "add+sb    ");   // mem[255] = $s1 = 1+2 = 3

        // =======================================================
        // TEST GROUP 2 – EXTENDED INSTRUCTION SET
        //
        // We clear RAM and manually load a new program.
        // Operands: $s1 = mem[90] = 10,  $s2 = mem[91] = 7
        // Tests: add, sub, and, or, slt, addi, beq(taken),
        //        beq(not-taken), j
        // =======================================================
        $display("\n====================================================");
        $display(" TEST GROUP 2: extended instructions");
        $display("====================================================");

        clear_ram;

        // --- data operands ---
        memory.mips_ram[90] = 8'd10;
        memory.mips_ram[91] = 8'd7;

        // 0-3: lb $s1, 90($0)   op=100000 rs=000 rt=001=$s1 imm=90
        memory.mips_ram[0]  = 8'b10000000;
        memory.mips_ram[1]  = 8'b00000001;
        memory.mips_ram[2]  = 8'b00000000;
        memory.mips_ram[3]  = 8'd90;

        // 4-7: lb $s2, 91($0)   rt=010=$s2 imm=91
        memory.mips_ram[4]  = 8'b10000000;
        memory.mips_ram[5]  = 8'b00000010;
        memory.mips_ram[6]  = 8'b00000000;
        memory.mips_ram[7]  = 8'd91;

        // 8-11: add $s3, $s1, $s2  rs=001 rt=010 rd=011 funct=100000
        memory.mips_ram[8]  = 8'h00;
        memory.mips_ram[9]  = 8'h22;
        memory.mips_ram[10] = 8'h18;
        memory.mips_ram[11] = 8'h20;

        // 12-15: sb $s3, 200($0)  op=101000 rs=000 rt=011=$s3 imm=200
        memory.mips_ram[12] = 8'b10100000;
        memory.mips_ram[13] = 8'b00000011;
        memory.mips_ram[14] = 8'b00000000;
        memory.mips_ram[15] = 8'd200;

        // 16-19: sub $s4, $s1, $s2  funct=100010
        memory.mips_ram[16] = 8'h00;
        memory.mips_ram[17] = 8'h22;
        memory.mips_ram[18] = 8'h20;
        memory.mips_ram[19] = 8'h22;

        // 20-23: sb $s4, 201($0)  rt=100=$s4
        memory.mips_ram[20] = 8'b10100000;
        memory.mips_ram[21] = 8'b00000100;
        memory.mips_ram[22] = 8'b00000000;
        memory.mips_ram[23] = 8'd201;

        // 24-27: and $s5, $s1, $s2  funct=100100
        memory.mips_ram[24] = 8'h00;
        memory.mips_ram[25] = 8'h22;
        memory.mips_ram[26] = 8'h28;
        memory.mips_ram[27] = 8'h24;

        // 28-31: sb $s5, 202($0)  rt=101=$s5
        memory.mips_ram[28] = 8'b10100000;
        memory.mips_ram[29] = 8'b00000101;
        memory.mips_ram[30] = 8'b00000000;
        memory.mips_ram[31] = 8'd202;

        // 32-35: or $s6, $s1, $s2  funct=100101
        memory.mips_ram[32] = 8'h00;
        memory.mips_ram[33] = 8'h22;
        memory.mips_ram[34] = 8'h30;
        memory.mips_ram[35] = 8'h25;

        // 36-39: sb $s6, 203($0)  rt=110=$s6
        memory.mips_ram[36] = 8'b10100000;
        memory.mips_ram[37] = 8'b00000110;
        memory.mips_ram[38] = 8'b00000000;
        memory.mips_ram[39] = 8'd203;

        // 40-43: slt $s7, $s2, $s1   ($s2=7 < $s1=10 → 1)
        memory.mips_ram[40] = 8'h00;
        memory.mips_ram[41] = 8'h41;
        memory.mips_ram[42] = 8'h38;
        memory.mips_ram[43] = 8'h2A;

        // 44-47: sb $s7, 204($0)  rt=111=$s7
        memory.mips_ram[44] = 8'b10100000;
        memory.mips_ram[45] = 8'b00000111;
        memory.mips_ram[46] = 8'b00000000;
        memory.mips_ram[47] = 8'd204;

        // 48-51: addi $s1, $s1, 5    $s1 = 10+5 = 15
        memory.mips_ram[48] = 8'h20;
        memory.mips_ram[49] = 8'h21;
        memory.mips_ram[50] = 8'h00;
        memory.mips_ram[51] = 8'd5;

        // 52-55: sb $s1, 205($0)
        memory.mips_ram[52] = 8'b10100000;
        memory.mips_ram[53] = 8'b00000001;
        memory.mips_ram[54] = 8'b00000000;
        memory.mips_ram[55] = 8'd205;

        // 56-59: beq $s2, $s2, +2   (taken – skip instr at 60)
        memory.mips_ram[56] = 8'h10;
        memory.mips_ram[57] = 8'h42;
        memory.mips_ram[58] = 8'h00;
        memory.mips_ram[59] = 8'd2;

        // 60-63: sb $s1, 210($0)  ← SKIPPED by beq above
        memory.mips_ram[60] = 8'b10100000;
        memory.mips_ram[61] = 8'b00000001;
        memory.mips_ram[62] = 8'b00000000;
        memory.mips_ram[63] = 8'd210;

        // 64-67: beq $s1, $s2, +2   ($s1=15 ≠ $s2=7, NOT taken)
        memory.mips_ram[64] = 8'h10;
        memory.mips_ram[65] = 8'h22;
        memory.mips_ram[66] = 8'h00;
        memory.mips_ram[67] = 8'd2;

        // 68-71: sb $s1, 211($0)   ← executed (branch not taken)
        memory.mips_ram[68] = 8'b10100000;
        memory.mips_ram[69] = 8'b00000001;
        memory.mips_ram[70] = 8'b00000000;
        memory.mips_ram[71] = 8'd211;

        // 72-75: j 76   (jump to byte address 76)
        memory.mips_ram[72] = 8'h08;
        memory.mips_ram[73] = 8'h00;
        memory.mips_ram[74] = 8'h00;
        memory.mips_ram[75] = 8'd19;

        // 76-79: sb $s1, 212($0)   ← j lands here
        memory.mips_ram[76] = 8'b10100000;
        memory.mips_ram[77] = 8'b00000001;
        memory.mips_ram[78] = 8'b00000000;
        memory.mips_ram[79] = 8'd212;

        // 80-83: j 0   (infinite loop)
        memory.mips_ram[80] = 8'h08;
        memory.mips_ram[81] = 8'h00;
        memory.mips_ram[82] = 8'h00;
        memory.mips_ram[83] = 8'h00;

        do_reset;
        $display("Reset released at cycle %0d. Running...", cycle);

        repeat(350) @(posedge clk);

        $display("Checking after %0d cycles:", cycle);

        // Arithmetic / Logic
        check_mem(8'd200, 8'd17, "add:$s3=17");   // 10+7
        check_mem(8'd201, 8'd3,  "sub:$s4=3 ");   // 10-7
        check_mem(8'd202, 8'd2,  "and:$s5=2 ");   // 10&7
        check_mem(8'd203, 8'd15, "or:$s6=15 ");   // 10|7
        check_mem(8'd204, 8'd1,  "slt:$s7=1 ");   // 7<10 → 1
        check_mem(8'd205, 8'd15, "addi:$s1=15");  // 10+5

        // Branch (taken) – sb at 60 must be skipped
        check_mem(8'd210, 8'd0,  "beq-taken ");

        // Branch (not taken) – sb at 68 must execute
        check_mem(8'd211, 8'd15, "beq-ntaken");

        // Jump – sb at 76 must execute
        check_mem(8'd212, 8'd15, "j target  ");

        // -------------------------------------------------------
        // Summary  (Lab 3 item #10 self-checking)
        // -------------------------------------------------------
        $display("\n====================================================");
        if (errors == 0)
            $display(" ALL CHECKS PASSED");
        else
            $display(" %0d CHECK(S) FAILED", errors);
        $display("====================================================\n");

        $finish;
    end

    // --- Simulation timeout watchdog  (Lab 3 item #8) ---
    initial begin
        #finishtime;
        $display("TIMEOUT at %0t ns – simulation forced to end.", $time);
        $finish;
    end

endmodule
